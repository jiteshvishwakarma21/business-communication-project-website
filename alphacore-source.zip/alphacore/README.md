# Alphacore

A five-route product concept site built with React, TypeScript, Vite/Vinext, Three.js, custom GLSL, and GSAP ScrollTrigger. The server runs on Cloudflare Workers through Sites.

## Run locally

Requires Node 22.13+.

```sh
npm ci
cp .env.example .env
npm run dev
```

Open the exact URL printed by the development server. `npm run build` produces the Worker and client assets in `dist/`. `npm run start` serves that production output locally.

## Architecture and editing

- `app/`: five pages, page metadata, sitemap, robots, and server enquiry endpoint.
- `components/alphacore/`: navigation, product viewer, scene lifecycle, contact form.
- `lib/three/model.ts`: editable procedural concept dimensions and materials. No final hardware specifications are implied.
- `lib/three/shaders.ts`: original decorative display core shader.
- `app/globals.css`: palette, typography, responsive layouts, reduced-motion styles.
- `public/brand/`: original SVG symbol, wordmark, monochrome, and small variants.
- `public/og.png`: social sharing capture of the updated dual-screen 3D concept.
- `public/product-fallback.png`: static capture of the actual procedural model for WebGL fallback.

The scene caps rendering resolution, observes viewport visibility, pauses rendering in hidden tabs, respects reduced motion, and disposes its resources on unmount. Touch interaction retains vertical page scrolling. View buttons provide a keyboard-accessible alternative to dragging.

## Email setup

No live email credentials were provided. Submissions currently return HTTP 503 and truthfully explain that nothing was saved. The direct email link works independently.

1. Create a Resend account and verify a sending domain.
2. Configure server-side `RESEND_API_KEY` and `CONTACT_FROM` through Sites runtime secrets. Never put the key in a public/VITE-prefixed variable.
3. Deploy again to apply the runtime environment.
4. Remove the pending-delivery notice in ContactForm and update the privacy notice with the actual provider, jurisdiction, and retention policy.
5. Send one authorized test enquiry and confirm inbox delivery before launch.

The endpoint validates length, email, required fields, consent, enquiry type, origin, content type, hidden honeypot, and elapsed time. It does not save messages. Add hosting rate limits / Turnstile before a high-traffic public campaign. Provider failures never return a success message.

## Deployment

The Sites identity is retained in `.openai/hosting.json`. Publish with the Sites plugin workflow; it builds the Worker, saves source, packages output, and deploys a version. This preview is private. Public access and a custom domain can be configured when the customer is ready. When changing domains, update metadataBase, JSON-LD URL, sitemap, and robots sitemap URL.

## Before customer launch

- Confirm final hardware appearance, input method, accessories, ports, dimensions, display, processor, graphics, memory, storage, battery, and charging.
- Replace or approve the procedural concept and social image.
- Provide the verified email sender and server secret.
- Approve business identity, operating jurisdiction, privacy terms, data retention, and domain.
- Confirm hosting and email-provider plan costs in those accounts; no paid services have been purchased.
- Confirm whether the site should become publicly accessible.

No checkout, prices, stock, launch dates, analytics, testimonials, or performance benchmarks are included.

## Dual-screen concept update

The product now has two display surfaces and an animated 180-degree unfolding control. In flat mode, the two shader UV regions form one seamless canvas. This is a design visualization, not validation of a physical creaseless panel. Customer-supplied server/workstation specifications are centralized in `lib/content/specifications.ts` and clearly labeled proposed, unverified configuration. The external monitors, rack form factor, PSU, UPS, and rack accessories are distinguished from laptop hardware.
